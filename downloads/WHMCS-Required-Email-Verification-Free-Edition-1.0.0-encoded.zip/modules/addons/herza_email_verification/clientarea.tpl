{literal}<style>
.hrev-wrap .hrev-verified,.hrev-wrap .hrev-verified strong{color:#146c43!important}
.hrev-wrap,.hrev-wrap .panel-body,.hrev-wrap .card-body{min-width:0}
.hrev-wrap .hrev-email,.hrev-wrap p,.hrev-wrap .alert{overflow-wrap:anywhere;word-break:break-word}
.hrev-wrap .btn{white-space:normal}
.hrev-wrap #hrev-email-code{width:100%;max-width:20rem}
.hrev-wrap a:focus-visible,.hrev-wrap button:focus-visible,.hrev-wrap input:focus-visible{outline:3px solid #0069d9;outline-offset:2px}
</style>{/literal}
<div class="hrev-wrap" lang="{if $hrevLanguage|default:'english' eq 'indonesian'}id{else}en{/if}">
    {if $hrevOwnerRequired|default:false}
        <div class="alert alert-info">{$hrevText.owner_required_help|escape:'html'}</div>
    {elseif $hrevEmailOnly|default:false}
        <div class="alert alert-info">{if $hrevEmailVerified}{$hrevText.email_verified|escape:'html'}{else}{if $hrevPilot|default:true}{$hrevText.pilot_intro|escape:'html'}{else}{$hrevText.required_intro|escape:'html'}{/if} {$hrevText.on_request|escape:'html'}{/if}</div>
    {/if}
    {if $hrevError}<div id="hrev-error" class="alert alert-danger" role="alert" tabindex="-1">{$hrevError|escape:'html'}</div>{/if}
    {if $hrevNotice}<div class="alert alert-success" role="status" aria-live="polite">{$hrevNotice|escape:'html'}</div>{/if}
    {if $hrevEnabled}
    {if $hrevEmailOnly|default:false}<p>{if $hrevEmailVerified}{$hrevText.complete_intro|escape:'html'}{else}{$hrevText.owner_intro|escape:'html'}{/if}</p>{/if}
    <div class="panel panel-default card mb-4"><div class="panel-body card-body">
        <h3>{$hrevText.owner_email|escape:'html'}</h3><p class="hrev-email">{$hrevEmail|escape:'html'}</p>
        {if $hrevEmailVerified}<p class="text-success hrev-verified"><strong>{$hrevText.verified|escape:'html'}</strong></p>{else}
        <form method="post" action="index.php?m=herza_email_verification">
            <input type="hidden" name="token" value="{$hrevWhmcsToken|escape:'html'}">
            <input type="hidden" name="hrev_token" value="{$hrevToken|escape:'html'}">
            <input type="hidden" name="hrev_action" value="request_email">
            <button type="submit" class="btn btn-primary">{$hrevText.request_email|escape:'html'}</button>
        </form>
        {if $hrevEmailChallenge}<form method="post" action="index.php?m=herza_email_verification" class="mt-3">
            <input type="hidden" name="token" value="{$hrevWhmcsToken|escape:'html'}">
            <input type="hidden" name="hrev_token" value="{$hrevToken|escape:'html'}">
            <input type="hidden" name="hrev_action" value="verify_email">
            <input type="hidden" name="hrev_challenge" value="{$hrevEmailChallenge|escape:'html'}">
            <label for="hrev-email-code">{$hrevText.email_code|escape:'html'}</label>
            <input id="hrev-email-code" name="hrev_code" class="form-control" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{literal}{6}{/literal}" maxlength="6" required aria-describedby="hrev-code-help{if $hrevError} hrev-error{/if}" aria-invalid="{if $hrevCodeError|default:false}true{else}false{/if}">
            <button type="submit" class="btn btn-primary mt-2">{$hrevText.verify_email|escape:'html'}</button>
        </form>{/if}{/if}
    </div></div>
    {if $hrevEmailVerified && ($hrevEmailOnly|default:false)}<a href="clientarea.php" class="btn btn-primary">{$hrevText.continue_clientarea|escape:'html'}</a> <a href="cart.php?a=view" class="btn btn-success">{$hrevText.return_cart|escape:'html'}</a>{/if}
    {if !$hrevEmailOnly|default:false || !$hrevEmailVerified}<p id="hrev-code-help" class="text-muted mt-3">{$hrevText.code_format_hint|escape:'html'} {$hrevText.code_help|escape:'html'}</p>{/if}
    {/if}
    {if !$hrevEmailVerified}
    <p class="hrev-recovery">
        {if $hrevAccountSwitchUrl|default:''}<a href="{$hrevAccountSwitchUrl|escape:'html'}">{$hrevText.switch_account|escape:'html'}</a> &middot; {/if}
        <a href="logout.php">{$hrevText.sign_out|escape:'html'}</a>
    </p>
    {/if}
</div>
